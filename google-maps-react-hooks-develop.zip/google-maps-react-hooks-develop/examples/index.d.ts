declare module 'google.maps';

/* eslint-disable init-declarations */
declare module '*.module.css' {
  const classes: {[key: string]: string};
  export default classes;
}
